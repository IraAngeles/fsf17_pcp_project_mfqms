exports.client_id = "--changeme--";
exports.client_secret = "--changeme--";
exports.authorization_url = "https://idaas.iam.ibm.com/idaas/oidc/endpoint/default/authorize";
exports.token_url = "https://idaas.iam.ibm.com/idaas/oidc/endpoint/default/token";
exports.issuer_id = "https://idaas.iam.ibm.com";
exports.callback_url = "--changeme--";      
